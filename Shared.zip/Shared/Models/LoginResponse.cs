﻿namespace Shared.Models
{
    public class LoginResponse
    {
        public string Token { get; set; }
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}